package com.capg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import bean.Employee;

public class EmpDAO {
	public int addEmployee(Employee emp)  {
		int n=0;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg520","training520");
			String insertQuery = "insert into employee1 values(?,?,?)";
			PreparedStatement pstmt = conn.prepareStatement(insertQuery);
			pstmt.setInt(1,emp.getEid());
			pstmt.setString(2,emp.getEname());
			pstmt.setDouble(3,emp.getSalary());
			n=pstmt.executeUpdate();
			conn.close();
		} 
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return n;
		
		
	}
}
