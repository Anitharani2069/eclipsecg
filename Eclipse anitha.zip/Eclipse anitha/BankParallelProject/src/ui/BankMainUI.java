package ui;
import java.util.Scanner;

public class BankMainUI {
	
	public static void main(String args[]) {
		int ch;
		char choice;
		BankModules bankModulesObj = new BankModules();
		Scanner s = new Scanner(System.in);
		
		do {
			System.out.println("1.Create Account");
			System.out.println("2.Show Balance");
			System.out.println("3.Deposit");
			System.out.println("4.WithDraw");
			System.out.println("5.FundTransfer");
			System.out.println("6.PrintTransactions");
			System.out.println("7.Exit");
			System.out.print("Enter your choice : ");
			ch = s.nextInt();
			switch(ch) {
			case 1:
				bankModulesObj.createAccount();
				break;
			case 2:
				bankModulesObj.showBalance();
				break;
			case 3:
				bankModulesObj.deposit();
				break;
			case 4:
				bankModulesObj.withdraw();
				break;
			case 5:
				bankModulesObj.fundTransfer();
				break;
			case 6:
				bankModulesObj.printTransactions();
				break;
			case 7:
				System.exit(0);
			}
			System.out.print("Do you want to continue (y/n)...? : ");
			choice = s.next().charAt(0);
			if(choice == 'y' || choice=='Y')
				continue;
			else {
				System.out.println("Thank You !");
				System.exit(0);
			}
		} while(ch != 7 );
		s.close();
	}
}
