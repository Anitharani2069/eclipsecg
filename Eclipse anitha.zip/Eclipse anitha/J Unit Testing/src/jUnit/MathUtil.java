package jUnit;

public class MathUtil {
	

	public int multiply(int i, int j) {
		int c=i*j;
		return c;
	}
}
