package jUnit;

public enum ColorType {
RED, BLUE, GREEN;
}
