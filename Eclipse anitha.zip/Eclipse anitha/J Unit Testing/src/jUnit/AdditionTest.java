package jUnit;
import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import  org.junit.jupiter.api.Test;
public class AdditionTest {
	static Addition a=new Addition();
	@Test
	void test()
{
		//static Addition a=new Addition();
		int expected=5;
		int actual=a.add(2,3);
		assertEquals(expected,actual);
		
		}
	/*@Test
	void test1()
	{
		Addition a=new Addition();
		int expected=6;
		int actual=a.add(2,3);
		assertEquals(expected,actual);
		
		}*/
	@BeforeAll
	static void initClass() {
		a=new Addition();
		System.out.println("Before All");
	}
	@BeforeEach
	void init() {
		a=new Addition();
		System.out.println("Before Each");
	}
	@AfterAll
	static void init1() {
		a=new Addition();
		System.out.println("After All");
	} 
	@Test
	void testAssumption() {
		boolean serverStatus=false;
		assumeTrue(serverStatus);
	}
	@RepeatedTest(5)
	void test2() {
		System.out.println("@RepeatedTest Simple Example");
	}
	}
