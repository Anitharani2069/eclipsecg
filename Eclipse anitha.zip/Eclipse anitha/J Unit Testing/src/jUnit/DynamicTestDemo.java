package jUnit;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.DynamicTest.dynamicTest;
import java.util.Arrays;
import java.util.List;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

 

public class DynamicTestDemo {
    
@TestFactory
List<DynamicTest> dynamicTestDemo()
{
return Arrays.asList(
        dynamicTest("simple dynamic test",()->assertTrue(true)),
        dynamicTest("Exception Executable",()->assertTrue(true))
        );
}
@ParameterizedTest
@ValueSource(ints = {1,2,3})
void test_valueSource(int i)
{
    assertTrue(i<5);
}
@ParameterizedTest
@EnumSource(ColorType.class)
void test_EnumSource(ColorType e)
{
    System.out.println(e);
}
@ParameterizedTest
@MethodSource("ms")
void test_methodSource(String s)
{
    s="hello";
    assertNotNull(s);
}
@ParameterizedTest
@CsvSource(delimiter=',', value= {"1,B","2,A"})
void test_CsvSource(int i,String s){
    assertTrue(3>i);
    assertTrue(Arrays.asList("A","B").contains(s));
}
}