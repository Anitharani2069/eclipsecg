package ui;
import java.util.Scanner;
import bean.Customer;
import bean.Mobile;
import bean.SimType;
public class Main {
	static void  addMobileDetails() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Mobile no:");
		long mobileNo=sc.nextLong();
		System.out.println("Enter State name:");
		String stateName=sc.next();
		System.out.println("Enter Sim tyoe[International/National]");
		String simType=sc.next();
	}
	static void addCustomerDetails(){
		
	}
	
	
	public static void main(String args[]) {
		}
		
	}
