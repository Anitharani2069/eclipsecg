package service;
import bean.Customer;
public interface CustomerServiceInterface {
	
}
