package service;
import java.util.Scanner;
public class CustomerService implements CustomerServiceInterface{
}