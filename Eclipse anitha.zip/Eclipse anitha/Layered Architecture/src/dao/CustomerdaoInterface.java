package dao;

public interface CustomerdaoInterface {

}
