package dao;
import java.util.Scanner;

import bean.Mobile;
public class CustomerDao implements CustomerdaoInterface {
	public void addMobile(Mobile m) {
		
	}
}
