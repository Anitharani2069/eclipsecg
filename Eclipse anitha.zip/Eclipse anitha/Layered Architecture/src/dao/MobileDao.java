package dao;

public class MobileDao {

}
