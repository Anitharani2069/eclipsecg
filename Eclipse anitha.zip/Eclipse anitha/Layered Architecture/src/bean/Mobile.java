package bean;
public class Mobile {
private long mobileNo;
private String state;
private String simCategory;
public Mobile(long mobileNo, String state, String simCategory) {
	super();
	this.mobileNo = mobileNo;
	this.state = state;
	this.simCategory = simCategory;
}
public long getMobileNo() {
	return mobileNo;
}
public void setMobileNo(long mobileNo) {
	this.mobileNo = mobileNo;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public String getSimCategory() {
	return simCategory;
}
public void setSimCategory(String simCategory) {
	this.simCategory = simCategory;
}
@Override
public String toString() {
	return "Mobile [mobileNo=" + mobileNo + ", state=" + state + ", simCategory=" + simCategory + "]";
}

}