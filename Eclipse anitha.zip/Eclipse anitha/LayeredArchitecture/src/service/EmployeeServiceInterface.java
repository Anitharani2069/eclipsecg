package service;
import bean.Employee;
public interface EmployeeServiceInterface {
public statc void ()
}
