package ui;

public class EmployeeDetails {

}
