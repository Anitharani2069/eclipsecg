package ui;
import java.util.Scanner;
import bean.Employee;
public class EmployeeClassUi {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Employee Id :");
		int eId=sc.nextInt();
		System.out.println("Employee Name :");
		String eName=sc.next();
		System.out.println("Employee Salary :");
		double eSalary=sc.nextDouble();
		System.out.println("Employee Designation :");
		String eDesignation=sc.next();
		System.out.println("Employee InsuranceScheme :");
		String eInsuranceScheme=sc.next();
		Employee e=new Employee(eId,eName,eSalary,eDesignation,eInsuranceScheme);
		System.out.println(e);
	}

}
