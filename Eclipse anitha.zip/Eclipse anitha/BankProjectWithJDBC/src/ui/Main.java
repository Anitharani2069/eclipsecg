package ui;

import java.util.Scanner;

import service.AccountService;

public class Main {
	public static void main(String args[]) 
	{
	
	AccountService accountService=new AccountService();

	for(;;)
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("1. Create Account");
		System.out.println("2. Show Balance");
		System.out.println("3. Deposit Amount");
		System.out.println("4. Withdraw Amount");
		System.out.println("5. Fund Transfer");
		System.out.println("6. All Details");
		System.out.println("7. Exit");
		System.out.println("Enter your choice:");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:accountService.createAccount();
				//bs.createAccount();
				break;
		case 2:	accountService.showBalance();
				break;
		case 3:accountService.depositAmount();
				break;
		case 4:accountService.withdrawBalance();
				break;
		case 5:accountService.fundTransaction();
				break;
		case 6:	accountService.displayAllDetails();
				break;
		
		case 7: System.exit(0);
			break;
			
	}
	System.out.println("do you want to continue");
		String str=sc.next();
		if(str.equals("y")||str.equals("Y"))
		{
			continue;
		}
		else
		{
			break;
		}
	}

}

}
