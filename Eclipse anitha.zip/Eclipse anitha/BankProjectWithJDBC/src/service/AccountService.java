package service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import bean.Account;
import bean.AccountType;

public class AccountService {
	Scanner scanner=new Scanner(System.in);

	public void createAccount()
	{

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection connection=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg520","training520");
			Statement stmt = connection.createStatement();

			System.out.println("Enter Account Holder:");
			String accountHolder=scanner.next();
			System.out.println("Enter Account Type:");
			String accType = scanner.next();
			PreparedStatement pst=connection.prepareStatement("insert into account values(accountNo_sequence.nextval,0,?,?)");
			pst.setString(1,accountHolder);
			pst.setString(2,accType);
			pst.executeUpdate();
			System.out.println("Account is created");
			}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}  
	}
	public void showBalance()
	{
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection connection=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg520","training520");
		Statement stmt = connection.createStatement();
		System.out.println("Enter account number:");
		int accountNo=scanner.nextInt();
		ResultSet resultSet=stmt.executeQuery("select balance from account where accountNo="+accountNo);
		while(resultSet.next())
		{
			System.out.println("Your Balance is:"+resultSet.getInt("balance"));
		}
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}  
	}
	public void depositAmount() 
	{
		try{
			ResultSet resultSet=null;

			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection connection=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg520","training520");
			Statement stmt = connection.createStatement();
			System.out.println("Enter account number to deposit amount:");
			int accountNo=scanner.nextInt();
			
			 resultSet=stmt.executeQuery("select balance from account where accountNo="+accountNo);
			int balance = 0;
			while(resultSet.next())
			{
				balance=resultSet.getInt("balance");
			}
			System.out.println("Enter amount to deposit:");
			int amount=scanner.nextInt();
			int balance1=balance+amount;
			PreparedStatement pst;
			pst=connection.prepareStatement("update account set balance=? where accountNo=?");
			pst.setInt(1, balance1);
			pst.setInt(2, accountNo);
			pst.executeUpdate();
			 resultSet=stmt.executeQuery("select balance from account where accountNo="+accountNo);
			while(resultSet.next())
			{
				System.out.println("Your balance is:"+resultSet.getInt("balance"));

			}
			
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}  
	
	}
	public void withdrawBalance()
	{
		try{
			ResultSet resultSet=null;
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection connection=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg520","training520");
			Statement stmt = connection.createStatement();
			System.out.println("Enter account number to withdraw amount:");
			int accountNo=scanner.nextInt();
			
			 resultSet=stmt.executeQuery("select balance from account where accountNo="+accountNo);
			int balance = 0;
			while(resultSet.next())
			{
				balance=resultSet.getInt("balance");
			}
			System.out.println("Enter amount to withdraw:");
			int amount=scanner.nextInt();
			int balance1=balance-amount;
			PreparedStatement pst;
			pst=connection.prepareStatement("update account set balance=? where accountNo=?");
			pst.setInt(1, balance1);
			pst.setInt(2, accountNo);
			pst.executeUpdate();
			 resultSet=stmt.executeQuery("select balance from account where accountNo="+accountNo);
			while(resultSet.next())
			{
				System.out.println("Your balance is:"+resultSet.getInt("balance"));

			}
			
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}  
	}
	public void fundTransaction()
	{
		ResultSet resultSet=null;

		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection connection=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg520","training520");
		Statement stmt = connection.createStatement();
		System.out.println("Enter account number from amount send:");
		int accountNo=scanner.nextInt();
		 resultSet=stmt.executeQuery("select balance from account where accountNo="+accountNo);
		int balance = 0;
		while(resultSet.next())
		{
			balance=resultSet.getInt("balance");
			System.out.println("bvalance is:"+balance);
		}
		System.out.println("Enter account number to get amount:");
		int accountNo1=scanner.nextInt();
		 resultSet=stmt.executeQuery("select balance from account where accountNo="+accountNo1);
		int balance1 = 0;
		while(resultSet.next())
		{
			balance1=resultSet.getInt("balance");
			System.out.println("bvalance is:"+balance1);
		}
		System.out.println("Enter amount to withdraw:");
		int amount=scanner.nextInt();
		int balance2=balance-amount;
		int balance3=balance1+amount;
		PreparedStatement pst;
		pst=connection.prepareStatement("update account set balance=? where accountNo=?");
		pst.setInt(1, balance2);
		pst.setInt(2, accountNo);
		pst.executeUpdate();
		 resultSet=stmt.executeQuery("select balance from account where accountNo="+accountNo);
		while(resultSet.next())
		{
			System.out.println("Your balance is:"+resultSet.getInt("balance"));

		}
		
		pst=connection.prepareStatement("update account set balance=? where accountNo=?");
		pst.setInt(1, balance3);
		pst.setInt(2, accountNo1);
		pst.executeUpdate();
		 resultSet=stmt.executeQuery("select balance from account where accountNo="+accountNo1);
		while(resultSet.next())
		{
			System.out.println("Your balance is:"+resultSet.getInt("balance"));
		}
		
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
	}
	public void displayAllDetails()
	{
		try{
			ResultSet resultSet=null;
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection connection=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg520","training520");
			Statement stmt = connection.createStatement();
			 resultSet=stmt.executeQuery("select * from account");
			int balance = 0;
			while(resultSet.next())
			{
				System.out.println("Account Number:" + resultSet.getInt("accountNo")+"Balance:" + resultSet.getInt("balance")+"Account Holder:" + resultSet.getString("accountHolder")+"Account Type:" + resultSet.getString("accountType"));
			}
		}
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} 
	}
}

