package bean;

public enum AccountType {
	SAVING,CURRENT

}
