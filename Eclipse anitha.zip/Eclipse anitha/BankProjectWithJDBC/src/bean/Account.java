package bean;
public class Account {
		private static int accountNo=1;
		private  int accountNumber;
		private double balance;
		private String accountHolder;
		AccountType accountType;
		private double deposit;
		private double withdraw;
	
		public Account(int accountNumber,  double deposit, double withdraw) {
			super();
			this.accountNumber = accountNumber;
			this.deposit = deposit;
			this.withdraw = withdraw;
		}
		public double getDeposit() {
			return deposit;
		}
		public void setDeposit(double deposit) {
			this.deposit = deposit;
		}
		public double getWithdraw() {
			return withdraw;
		}
		public void setWithdraw(double withdraw) {
			this.withdraw = withdraw;
		}
		public Account(){}
		public Account( String accountHolder, AccountType accountType) {
			super();
			this.accountNumber = accountNo++;
			this.accountHolder = accountHolder;
			this.accountType = accountType;
		}
		public Account(int accountNumber, String accountHolder, AccountType accountType) {
			super();
			this.accountNumber = accountNumber;
			this.accountHolder = accountHolder;
			this.accountType = accountType;
		}
		public Account(int accountNumber, double balance,String accountHolder, AccountType accountType) {
			super();
			this.accountNumber = accountNumber;
			this.accountHolder = accountHolder;
			this.accountType = accountType;
			this.balance=balance;
		}
		
		public int getAccountNumber() {
			return accountNumber;
		}
		public void setAccountNumber(int accountNumber) {
			this.accountNumber = accountNumber;
		}
		public  double getBalance() {
			return balance;
		}
		public  void setBalance(double balance) {
			this.balance = balance;
		}
		public String getAccountHolder() {
			return accountHolder;
		}
		public void setAccountHolder(String accountHolder) {
			this.accountHolder = accountHolder;
		}
		public AccountType getAccountType() {
			return accountType;
		}
		public void setAccountType(AccountType accountType) {
			this.accountType = accountType;
		}
		@Override
		public String toString() {
			return "Account [accountNumber=" + accountNumber + ", balance=" + balance + ", accountHolder="
					+ accountHolder + ", accountType=" + accountType + "]";
		}
		
		
}
