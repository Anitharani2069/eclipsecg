import java.util.Scanner;


public class UserInterface {



public static void main(String a[]){
Scanner scanner=new Scanner(System.in);
int noOfEmployees=scanner.nextInt();
String employees[]=new String[noOfEmployees];
for(int i=0;i<noOfEmployees;i++){
employees[i]=scanner.next();
}
int count=0;
StringBuilder builder = new StringBuilder();
for (String string : employees) {
	String[] information = new String[2];
	information = string.split(",");
	information[1] = information[1].replaceAll(":", "");
	int num = Integer.parseInt(information[1]);
	if (num > 930) {
		count++;
		builder.append(information[0] + " ");
	}
}
System.out.println(count + " " + builder.toString() + "are late");

scanner.close();
}}