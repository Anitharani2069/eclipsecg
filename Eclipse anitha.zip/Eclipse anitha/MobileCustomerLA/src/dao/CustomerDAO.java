package dao;

import bean.Customer;

public class CustomerDAO implements CustomerDAOIntf {
static Customer cObj[]=new Customer[100];
static int custIndex=0;
	public Customer retriveCustomerDetails(int custId) {
		Customer c=null;
		for(Customer cs:cObj)
		{
			if(cs!=null) {
				System.out.println("if block cs!null getId"+cs.getCustID());
				if(cs.getCustID()==custId)
					c=cs;
			}
		}
		
		return c;
		
	}
	public void storeCustomerDetails(Customer co) {
		int i=custIndex;
		cObj[i]=co;
		custIndex++;
		
	}
}
