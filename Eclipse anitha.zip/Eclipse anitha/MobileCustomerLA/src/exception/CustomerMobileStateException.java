package exception;

public class CustomerMobileStateException extends RuntimeException {
	public CustomerMobileStateException(){
	System.out.println("Customer state and Mobile state do not match");	
	}
	
	public CustomerMobileStateException(String args) {
		System.out.println(args);
		
	}
	

}
