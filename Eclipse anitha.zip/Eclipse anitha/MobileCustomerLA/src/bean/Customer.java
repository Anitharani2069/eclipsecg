package bean;

public class Customer {
	int custID;
	String Name;
	String state;
	Mobile mobileDetails;
	
	public Customer() {
		
	}
	public Customer(int custID, String name, String state, Mobile mobileDetails) {
		
		this.custID = custID;
		Name = name;
		this.state = state;
		this.mobileDetails = mobileDetails;
	}
	public int getCustID() {
		return custID;
	}
	public void setCustID(int custID) {
		this.custID = custID;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public Mobile getMobileDetails() {
		return mobileDetails;
	}
	public void setMobileDetails(Mobile mobileDetails) {
		this.mobileDetails = mobileDetails;
	}
	@Override
	public String toString() {
		return "Customer [custID=" + custID + ", Name=" + Name + ", state=" + state + ", mobileDetails=" + mobileDetails
				+ "]";
	}
	
	

}
