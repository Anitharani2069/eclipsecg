package bean;

public enum SimType{
	INTERNATIONAL,NATIONAL;
}