package service;

import bean.Customer;
import dao.CustomerDAO;
public class CustomerService implements CustomerServiceIntf {
	static CustomerDAO cdaoObj=new CustomerDAO();

	public Customer retriveCustomerService(int custId) {
		
		return cdaoObj.retriveCustomerDetails(custId);
	}
	public void storeCustomerService(Customer cObj) {
		
		cdaoObj.storeCustomerDetails(cObj);
		
	}
}
