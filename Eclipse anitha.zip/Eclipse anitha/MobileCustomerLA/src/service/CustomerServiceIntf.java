package service;

import bean.Customer;

public interface CustomerServiceIntf {
	Customer retriveCustomerService(int custId);
	void storeCustomerService(Customer cObj);
}
