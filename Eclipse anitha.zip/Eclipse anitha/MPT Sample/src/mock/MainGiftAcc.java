package mock;

import java.util.Scanner;

public class MainGiftAcc
{


	public static void main(String args[])
	{
		Scanner scanner=new Scanner(System.in);
		int n=scanner.nextInt();
		String str=MainGiftAcc.validateAccessCode(n);
		scanner.close();
		if(str.length()==4) {
			int sum=0;
			for(int i=1;i<str.length();i=i+2) {
				sum=sum+str.charAt(i);
			}
			String str3="Invalid Access Code";
			if(sum%2==0) {
				str3="Valid Access Code";
				System.out.println(str3);
			}
			else {
				System.out.println(str3);
			}
		}
		else {
			System.out.println("Invalid Input");
		}

	}

	public static String validateAccessCode(int accessCode)
	{
		String str1=Integer.toString(accessCode);
		return str1;
	}
}