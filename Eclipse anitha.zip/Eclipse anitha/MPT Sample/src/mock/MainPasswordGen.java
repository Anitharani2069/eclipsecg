package mock;

import java.util.Scanner;

import java.io.*;
public class MainPasswordGen
{

        public static void main(String args[])
        {
        	Scanner scanner=new Scanner(System.in);
        	String input=scanner.nextLine();
        	System.out.println(generate(input));
        }


        public static String generate(String s) 
        {
        	StringBuilder builder=new StringBuilder();
            String output="";
            if(s.length()>=5) {
            	for(int i=0;i<s.length();i=i+2) {
            		builder.append(s.charAt(i));
            	}
            	output=builder.toString().toUpperCase();
            }else {
            	output="Invalid input";
            }
           return output;
        }
}
