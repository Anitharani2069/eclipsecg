package mock;

import java.util.Scanner;

public class MainCountDigit
{ 


	public static void main(String args[])
	{
		Scanner scanner=new Scanner(System.in);
		int input1=scanner.nextInt();
		int input2=scanner.nextInt();
		int result=count(input1,input2);
		System.out.println(result);
	}

	public static int count(int n1,int n2)   { 
		int count=0;
		String number=String.valueOf(n1);
		for(int i=0;i<number.length();i++)
		{
			char ch=number.charAt(i);
			int value = Integer.parseInt(String.valueOf(ch));
			if(value==n2) {
				count++;
			}
		}
		
		return count;
	}
}



