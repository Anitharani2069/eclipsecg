package service;

import bean.BankAccBean;

public class BankService implements BankServiceIntf{
public static void createAccount() {
		
	}
	public static double showBalance(BankAccBean a) {
		
		return a.getBalanceAmount();
	}
	public static double deposit(BankAccBean a, double amount ) {
		double balance=a.getBalanceAmount();
		amount=amount+balance;
		a.setBalanceAmount(amount);
		return a.getBalanceAmount();
	}
	
	public static double withDraw(BankAccBean a,double amount) {
		double balance=a.getBalanceAmount();
		if(balance<amount)
		System.out.println("Your balance is insuffiecient");
		else
		{
			amount=balance-amount;
			a.setBalanceAmount(amount);
		}
		return a.getBalanceAmount();
	}
	public static double fundTransfer(BankAccBean a,BankAccBean b,double amount) {
		double balance=a.getBalanceAmount();
		if(balance<=amount)
		System.out.println("Your balance is insuffiecient");
		else
		{
			amount=balance-amount;
			a.setBalanceAmount(amount);
		}
		return amount;
	}
	public static void printTransactions(){
	
}
	public static void showDetails(){
		
	}

}
