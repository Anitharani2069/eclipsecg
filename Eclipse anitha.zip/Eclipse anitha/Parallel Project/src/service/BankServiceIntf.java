package service;

import bean.BankAccBean;

public interface BankServiceIntf {
	
	}
