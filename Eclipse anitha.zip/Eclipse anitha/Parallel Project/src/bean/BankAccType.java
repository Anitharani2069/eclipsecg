package bean;

public enum BankAccType {
	SAVINGSACCOUNT,CURRENTACCOUNT
}
