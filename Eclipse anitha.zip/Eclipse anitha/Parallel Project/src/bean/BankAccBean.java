package bean;
public class BankAccBean {
	private long accNo;
	private static double balanceAmount=0;
	private String accountHolder;
	private BankAccType accountType;
	public BankAccBean() {
		
	}
	public BankAccBean(long accNo, String accountHolder, BankAccType accountType) {
		super();
		this.accNo = accNo;
		this.accountHolder = accountHolder;
		this.accountType = accountType;
	}
	public long getAccNo() {
		return accNo;
	}
	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}
	public static double getBalanceAmount() {
		return balanceAmount;
	}
	public static void setBalanceAmount(double balanceAmount) {
		BankAccBean.balanceAmount = balanceAmount;
	}
	public String getAccountHolder() {
		return accountHolder;
	}
	public void setAccountHolder(String accountHolder) {
		this.accountHolder = accountHolder;
	}
	public BankAccType getAccountType() {
		return accountType;
	}
	public void setAccountType(BankAccType accountType) {
		this.accountType = accountType;
	}
	@Override
	public String toString() {
		return "BankAccBean [accNo=" + accNo + ", accountHolder=" + accountHolder + ", accountType=" + accountType
				+ "]";
	}
	
}