package ui;
import java.util.Scanner;

import bean.BankAccBean;
import bean.BankAccType;
import dao.BankDao;
import service.BankService;
public class Main {	
	static BankService bs=new BankService();
	static BankAccBean ba1=new BankAccBean();
	static BankAccBean ba2=new BankAccBean();
	static BankAccBean ba3=new BankAccBean();
	static BankAccBean ba4=new BankAccBean();
	static BankAccBean ba5=new BankAccBean();
	static BankAccBean ac=new BankAccBean();
	static Scanner sc=new Scanner(System.in);
	static void createAccount() {
		System.out.println("Enter the account no");
		long accNo=sc.nextLong();	
		System.out.println("Enter the account holder name");
		String accHolder=sc.next();
		System.out.println("Enter the account type");
		String accType=sc.next();
		BankAccBean bb=new BankAccBean(accNo,accHolder,BankAccType.valueOf(accType.toUpperCase()));
		System.out.println(bb);
		BankDao.set.add(bb);
		
		}
	static void showBalance()
	{
		System.out.println("The available balance is "+bs.showBalance(ba1));
		
	}
	static void deposit() {
		System.out.println("Enter the amount to deposit");
		double amount=sc.nextDouble();
		System.out.println("Amount deposited Successfully!");
		System.out.println("The available balance is "+bs.deposit(ba2,amount));
	}
	static void withDraw(){
		System.out.println("Enter the amount to withdraw");
		double amount=sc.nextDouble();
		System.out.println("The available balance is "+bs.withDraw(ba3,amount));
	}
	static void fundTransfer()
	{
		System.out.println("Enter the source account no");
		long acc1=sc.nextLong();
		System.out.println("Enter the destination account no");
		Long acc2=sc.nextLong();
		System.out.println("Enter the amount to tarnsfer");
		double amount=sc.nextDouble();
		System.out.println("Amount transfered Successfully!");
		System.out.println("The available balance is "+bs.fundTransfer(ba4,ac,amount));	
	}	
	static void showDetails() {
		BankDao bad=new BankDao();
		bad.retrieveDetails();
	}
	public static void main(String args[]) {
	int ch;
	char choice;
	BankDao bc=new BankDao();
	bc.storeDetails();
	do
	{
		
		System.out.println("Main Menu");
		System.out.println("1.Create Account");
		System.out.println("2.Show Balance");
		System.out.println("3.Deposit");
		System.out.println("4.WithDraw");
		System.out.println("5.FundTransfer");
		System.out.println("6.Print Transactions");
		System.out.println("7.ShowDetails");
		System.out.println("8.Exit");
		System.out.println("Enter your choice:");
		ch=sc.nextInt();
		switch(ch)
		{
		case 1:
			createAccount();
			break;
		case 2:
			showBalance();
			break;
		case 3:
			deposit();
			break;
		case 4:
			withDraw();
			break;
		case 5:
			fundTransfer();
			break;
		case 6:
			printTransactions();
			break;
		case 7:
			showDetails();
			break;
		case 8:
			System.exit(0);
			
		default :
			System.out.println("Enter Valid Choice:");
			break;
		}
		System.out.println("Do you want to continue (y/n)...? ");
		choice =sc.next().charAt(0);
		if(choice=='y'||choice=='Y')
			continue;
		else {
			System.out.println("Thankyou!");
			System.exit(0);
		}
	}
	while(ch!=8);
	sc.close();	
}
	private static void printTransactions() {
		// TODO Auto-generated method stub
		
	}
}