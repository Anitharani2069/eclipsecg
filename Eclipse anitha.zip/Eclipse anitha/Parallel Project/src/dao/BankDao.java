package dao;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import bean.BankAccBean;
import bean.BankAccType;
public class BankDao implements BankDaoIntf{
	public static List<BankAccBean>set=new ArrayList<BankAccBean>();
	public void storeDetails(){
		BankAccBean bb=new BankAccBean(1234,"Anitha",BankAccType.CURRENTACCOUNT);
		BankAccBean bb1=new BankAccBean(2345,"Yamuna",BankAccType.SAVINGSACCOUNT);
		set.add(bb);
		set.add(bb1);
	}
	public void retrieveDetails() {
		for(int i=0;i<set.size();i++) 
			System.out.println(set.get(i).toString());
	}
}
