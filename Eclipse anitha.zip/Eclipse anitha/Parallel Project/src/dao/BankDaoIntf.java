package dao;

public interface BankDaoIntf {

}
