package ui;
import java.util.Scanner;

import bean.TableType;
import bean.CustomerDetails;
import bean.TableDetails;
import dao.CustomerDao;
import dao.TableDao;
import service.TableService;
import service.CustomerService;
public class Main {
	static TableDetails td=new TableDetails();
	static CustomerDetails ac=new CustomerDetails();
	static CustomerService cs=new CustomerService();
	static TableService ts=new TableService();
	static Scanner sc=new Scanner(System.in);
	static void showTableDetails() {
		TableDao tdd=new TableDao();
			tdd.retrieveTableDetails();
		}
	
	static  void bookTable() {
		System.out.println("enter mobile no");
		Long customerMobileNo=sc.nextLong();
		System.out.println("enter customer name");
		String custName=sc.next();
		System.out.println("enter the table type[TWOSEATER,FOURSEATER,SIXSEATER,EIGHTSEATER]");
		String tType=sc.next();
		CustomerDetails cd1=new CustomerDetails(customerMobileNo,custName,TableType.valueOf(tType.toUpperCase()));
		System.out.println(cd1);
		CustomerDao.set.add(cd1);
	
	}
	static void addNewTable(){
		System.out.println("enter table no");
		int tableNo=sc.nextInt();
		System.out.println("enter table Id");
		int tableId=sc.nextInt();
		System.out.println("enter the table type[TWOSEATER,FOURSEATER,SIXSEATER,EIGHTSEATER]");
		String tType=sc.next();
		TableDetails tbd1=new TableDetails(tableNo,tableId,TableType.valueOf(tType.toUpperCase()));
		System.out.println(tbd1);
		TableDao.hm.add(tbd1);
		
	}
	static void displayCustomerDetails() {
		CustomerDao cds=new CustomerDao();
		cds.retrieveCustomerDetails();
	}
	public static void main(String args[]) {
	
	int ch;
	char choice;
	TableDao tdc=new TableDao();
	tdc.storeTableDetails();
	CustomerDao cdc=new CustomerDao();
	cdc.storeCustomerDetails();
	do 
	{
	System.out.println("MainMenu");
	System.out.println("1.Display Table details");
	System.out.println("2.Book A Table");
	System.out.println("3.Add a new Table to Restraunt");
	System.out.println("4.Display Customer Details");
	System.out.println("5.Exit");
	System.out.println("Enter your Choice");
	
	 ch=sc.nextInt();
	 switch(ch) 
	 {
	 case 1:
		 showTableDetails();
		 break;
	 case 2:
		 bookTable();
		 break;
	 case 3:
		 addNewTable();
		 break;
	 case 4:
		 displayCustomerDetails();
	 case 5:
		 System.exit(0);
		 break;
	 default :
			System.out.println("Enter Valid Choice:");
			break;
	 }
	System.out.println("Do you want to continue (y/n)...? ");
		choice =sc.next().charAt(0);
		if(choice=='y'||choice=='Y')
			continue;
		else {
			System.out.println("Thankyou!");
			System.exit(0);
		}
	}

	while(ch!=5);
	sc.close();	

}
}