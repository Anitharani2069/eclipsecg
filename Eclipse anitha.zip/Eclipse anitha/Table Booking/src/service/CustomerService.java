package service;

import bean.CustomerDetails;
import dao.CustomerDao;

public class CustomerService implements CustomerServiceInterface{
CustomerDao cd=new CustomerDao();
public void addTable(CustomerDetails cd2)
	{
	}
}
