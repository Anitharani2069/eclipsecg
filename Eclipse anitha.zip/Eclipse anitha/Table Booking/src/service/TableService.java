package service;

import bean.TableDetails;
import dao.TableDao;

public class TableService implements TableServiceInterface{
TableDao td=new TableDao();
public void showTables() {
	
}


public void addTable(TableDetails tds)
	{
	
	}
}
