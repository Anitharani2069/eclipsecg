package service;

public interface TableServiceInterface {

}
