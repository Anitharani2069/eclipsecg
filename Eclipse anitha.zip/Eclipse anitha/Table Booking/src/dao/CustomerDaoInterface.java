package dao;

public interface CustomerDaoInterface {

}
