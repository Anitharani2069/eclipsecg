package dao;

import java.util.ArrayList;
import java.util.List;
import bean.TableType;
import bean.CustomerDetails;

public class CustomerDao implements CustomerDaoInterface{
public static List<CustomerDetails>set=new ArrayList<CustomerDetails>();
	public void storeCustomerDetails() {
		CustomerDetails cd=new CustomerDetails(9963747,"Anitha",TableType.TWOSEATER);
		CustomerDetails cd1=new CustomerDetails(701382,"Raji",TableType.FOURSEATER);
		CustomerDetails cd2=new CustomerDetails(7702154,"Yamuna",TableType.SIXSEATER);
		CustomerDetails cd3=new CustomerDetails(9949481,"Pavani",TableType.EIGHTSEATER);
		set.add(cd);
		set.add(cd1);
		set.add(cd2);
		set.add(cd3);
	}
	public void retrieveCustomerDetails() {
		//storeTableDetails();
		for(int i=0;i<set.size();i++) 
			System.out.println(set.get(i).toString());
		
	}
}