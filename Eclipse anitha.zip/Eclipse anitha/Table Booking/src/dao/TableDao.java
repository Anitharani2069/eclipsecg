package dao;

import java.util.ArrayList;
import java.util.List;
import bean.TableDetails;
import bean.TableType;

public class TableDao implements TableDaoInterface{

public static List<TableDetails> hm=new ArrayList<TableDetails>();
public void storeTableDetails()
{
	TableDetails td=new TableDetails(123456,1,TableType.TWOSEATER);
	TableDetails td1=new TableDetails(456789,2,TableType.FOURSEATER);
	TableDetails td2=new TableDetails(567890,3,TableType.SIXSEATER);
	TableDetails td3=new TableDetails(678901,4,TableType.EIGHTSEATER);
	hm.add(td);
	hm.add(td1);
	hm.add(td2);
	hm.add(td3);
}
public void retrieveTableDetails() {
	for(int i=0;i<hm.size();i++) 
		System.out.println(hm.get(i).toString());
	
}	
}
