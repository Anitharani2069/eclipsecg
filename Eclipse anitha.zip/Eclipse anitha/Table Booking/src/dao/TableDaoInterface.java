package dao;

public interface TableDaoInterface {

}
