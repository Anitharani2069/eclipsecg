package bean;

public class CustomerDetails {
	long customerMobileNo;
	String custName;
	TableType tableType;
	public CustomerDetails() {
		super();
	}
	public CustomerDetails(long customerMobileNo, String custName, TableType tableType) {
		super();
		this.customerMobileNo = customerMobileNo;
		this.custName = custName;
		this.tableType = tableType;
	}
	public long getCustomerMobileNo() {
		return customerMobileNo;
	}
	public void setCustomerMobileNo(long customerMobileNo) {
		this.customerMobileNo = customerMobileNo;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public TableType getTableType() {
		return tableType;
	}
	public void setTableType(TableType tableType) {
		this.tableType = tableType;
	}
	@Override
	public String toString() {
		return "CustomerDetails [customerMobileNo=" + customerMobileNo + ", custName=" + custName + ", tableType="
				+ tableType + "]";
	}
}
