package bean;

public class TableDetails {
	int tableNo;
	int tableId;
	TableType tableType;
	public TableDetails() {
		
	}
	public TableDetails(int tableNo, int tableId, TableType tableType) {
		super();
		this.tableNo = tableNo;
		this.tableId = tableId;
		this.tableType = tableType;
	}
	public int getTableno() {
		return tableNo;
	}
	public void setTableno(int tableno) {
		this.tableNo = tableno;
	}
	public int getTableId() {
		return tableId;
	}
	public void setTableId(int tableId) {
		this.tableId = tableId;
	}
	public TableType getTableType() {
		return tableType;
	}
	public void setTableType(TableType tableType) {
		this.tableType = tableType;
	}
	@Override
	public String toString() {
		return "TableBookingDetails [tableno=" + tableNo + ", tableId=" + tableId + ", tableType=" + tableType + "]";
	}
}
