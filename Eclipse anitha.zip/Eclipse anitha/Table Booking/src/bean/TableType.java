package bean;

public enum TableType {
	TWOSEATER,FOURSEATER,SIXSEATER,EIGHTSEATER
}
