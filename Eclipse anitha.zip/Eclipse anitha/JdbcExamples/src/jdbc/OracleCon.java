package jdbc;

 

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Scanner;
import java.sql.*;

 

public class OracleCon {
    public static void main(String args[])
    {
        Scanner scan=new Scanner(System.in);
        // System.out.println("Enter user name");
         //String uname=scan.next();
         //System.out.println("Enter user id");
         //int uID=scan.nextInt();
        
         scan.close();
        try
        {
       Class.forName("oracle.jdbc.driver.OracleDriver");
       Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg521","training521");
       Statement stmt=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
       
       //stmt.execute("insert into cust values(4,'anjali')");
       //PreparedStatement pstmt=con.prepareStatement("update cust set customer_name=? where customer_id=?");
        //pstmt.setString(1,uname); 
       //pstmt.setInt(2,uID);
      // pstmt.executeUpdate();
      // System.out.println("row inserted");
       //System.out.println("row updated");
       ResultSet results=stmt.executeQuery("Select * from cust");
       int concurrency=results.getConcurrency();
       System.out.println(concurrency);
       System.out.println(ResultSet.CONCUR_UPDATABLE);
      if(concurrency==ResultSet.CONCUR_UPDATABLE)
      {
    	  results.absolute(1);
      	results.updateString(2,"ani");
      	results.updateRow();
      
      }
      else 
      {
    	  System.out.println("ResultSet is not an update result set.");
      } 
      while(results.next())
          System.out.println(results.getInt(1)+" "+results.getString(2));
         con.close();
        }catch(Exception e)
        {
            System.out.println(e);
        }
    }
}