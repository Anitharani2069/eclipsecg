package jdbc;
/*import java.sql.*;
public class StatementDemo {
public static void main(String args[]) {
	Connection con;
	Statement st;
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
	con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3::orcl","trg520","training520");
		st=con.createStatement();
			st.execute("insert into customers_50()");
			System.out.println("row updated");
	}catch(Exception e) {
		System.out.println(e);
	}
}
}*/

import java.sql.Connection;
import java.util.Scanner;
import java.sql.*;



public class OracleConnect {
public static void main(String args[])
{
	Scanner scanner=new Scanner(System.in);
	//System.out.println("enter user name");
	//String uName=scanner.next();
	//System.out.println("enter user id");
	//int uId=scanner.nextInt();
	scanner.close();
    try {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        
        Connection con=DriverManager.getConnection(
                "jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg520","training520");
                
        Statement stmt=con.createStatement();
        
        //stmt.execute("insert into customers_new51 values(60,'anitha','kulumanali',9010973158,'Kashmir')");
        //PreparedStatement pstmt=new con.prepareStatement("update customers_new51 set customer_name=? where customer_id=?");
        //System.out.println("row updated");
        ResultSet rs=stmt.executeQuery("select * from customers_new51");
        //System.out.println(rs);
        while(rs.next());
        System.out.println(rs.getInt(1)+" "+rs.getString(2));
        con.close();
    }catch(Exception e) {
    	System.out.println(e);
    	}
}
}
 