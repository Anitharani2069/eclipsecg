package service;

import java.util.Collection;

import bean.Account;
import exception.AccountNotFoundException;
import exception.InSufficientBalanceException;

public interface AccountService {
	public Account createAccount(Account account);
	public void deposit(int accountNo, double amount) throws AccountNotFoundException;
	public void withdraw(int accountNo, double amount) throws AccountNotFoundException, InSufficientBalanceException;
	public void fundsTransfer(int accountNoFrom, int accountNoTo, double amount) throws AccountNotFoundException, InSufficientBalanceException;
	public double getBalance(int accountNo) throws AccountNotFoundException;
	public Collection<Account> getTransactions();
}
