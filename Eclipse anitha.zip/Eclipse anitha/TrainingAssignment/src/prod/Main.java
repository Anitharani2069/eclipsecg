package prod;

public class Main {
	static void input(Base b) {
	}
	public static void main(String args[]) {
		Base b=new Base();
		Sub s=new Sub();
		input(b);
		input(s);
	}

}
