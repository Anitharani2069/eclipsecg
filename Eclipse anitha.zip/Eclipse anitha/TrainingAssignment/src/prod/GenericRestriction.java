package prod;

class Caluclator<T> {

}
