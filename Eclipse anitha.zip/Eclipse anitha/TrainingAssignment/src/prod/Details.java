package prod;
import java.util.*;
public class Details {
public static void main(String args[]) {

      HashMap<Integer,Integer> hm = new HashMap<Integer,Integer>();

      hm.put(12,144);
      hm.put(2,4);
      hm.put(7,49);

      Set set = hm.entrySet();
      Iterator itr = set.iterator();
      int Set;
      while(itr.hasNext()) {
         Map.Entry mentry = (Map.Entry)itr.next();
         System.out.print("key is: "+ mentry.getKey() + " & Value is: ");
         System.out.println(mentry.getValue());
       }
	}
}