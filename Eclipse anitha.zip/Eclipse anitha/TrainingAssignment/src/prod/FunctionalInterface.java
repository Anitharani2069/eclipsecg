package prod;

public interface FunctionalInterface {
public  int fun(int arg);
}
