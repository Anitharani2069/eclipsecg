package prod;
interface Sum
{
    void abstractfun(int n);
}
public class LambdaExpression {
    public static void main(String args[])
    {
        Sum f=(int n)->System.out.println(n+10);
        f.abstractfun(6);
    }

}