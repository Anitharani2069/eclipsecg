package prod;

public class Sample {
public static void main(String args[]) {
	MyThread obj=new MyThread();
	Thread tObj=new Thread(obj);
	tObj.start();
}
}
