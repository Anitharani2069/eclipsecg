package prod;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public class StreamClass {
	public static void main(String args[]) {
		List<Integer> l=new ArrayList<Integer>();
		l.add(1);
		l.add(2);
		l.add(3);
		l.add(4);
		Stream<Integer> s=l.stream();
		//Stream<Integer> b=s.filter(i->i%2==0);
		//b.forEach(System.out::println);
		//List<Integer> obj=b.collect(Collectors.toList());
		//System.out.println(obj);
		//List updateList=l.stream().map(i->i+3).collect(Collectors.toList());
		//List updateList=b.map(i->i+3).collect(Collectors.toList());
		//System.out.println(updateList);
		//long c=b.count();
		//System.out.println(c);
		//Stream d=s.distinct();
		//d.forEach(System.out::println);
		Optional<Integer> e=s.reduce((a,b)->a+b);
		System.out.println(e);
	}
}
