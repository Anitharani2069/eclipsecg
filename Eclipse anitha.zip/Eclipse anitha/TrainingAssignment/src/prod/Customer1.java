package prod;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class Customer1 implements Comparable<Customer1>{
int customerId;
String customerName;
public Customer1() {
	}
public Customer1(int customerId, String customerName) {
	super();
	this.customerId = customerId;
	this.customerName = customerName;
}
public int compareTo(Customer1 c)
{
    if(customerId >c.customerId)
    {
        return 1;
    }
    else if(customerId<c.customerId)
    {
        return -1;
    }
    else
        return 0;
    }
@Override
public String toString() {
	return "Customer [customerId=" + customerId + ", customerName=" + customerName + "]";
}
public int getCustomerId() {
	return customerId;
}
public void setCustomerId(int customerId) {
	this.customerId = customerId;
}
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public static class Question1 {

public static void main(String args[]) {
	Set<Customer1> customerDetails=new TreeSet<Customer1>();
	
	Customer1 customerObj=new Customer1(1,"Anitha");
	Customer1 customerObj1=new Customer1(2,"raji");
	Customer1 customerObj2=new Customer1(3,"yamuna");
	customerDetails.add(customerObj);
	customerDetails.add(customerObj1);
	customerDetails.add(customerObj2);
	for(Customer1 c:customerDetails) { 
		System.out.println(c.customerId+" "+c.customerName);
	}
}
}
}
