package prod;
import java.util.Scanner;
public class LambdaTest {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	int num=sc.nextInt();
	FunctionalInterface a= (arg)->arg +10;
	System.out.println(a.fun(num));
	sc.close();
}
}
