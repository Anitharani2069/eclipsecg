package prod;
public class Question13 {
	static void display() {
		throw new RuntimeException(" Hi ");
		System.out.print(" Hello World ");
	}
public static void main(String[] args) {
	try {
		display();
	}catch(RuntimeException e) {
		System.out.print(e);
	}
	catch(Exception e) {
		System.out.print(e);
	}
}
}
