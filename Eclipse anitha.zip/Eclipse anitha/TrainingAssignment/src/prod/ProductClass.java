package prod;
import java.util.Scanner;
public class ProductClass {
	public static void main(String args[])
	{
	Scanner sc=new Scanner(System.in);
	int PId=sc.nextInt();
	String PN=sc.next();
	int PQ=sc.nextInt();
	double PP=sc.nextDouble();
	System.out.println("ProductName : " +PN);
	System.out.println("ProductId : " +PId);
	System.out.println("ProductQuantity : " +PQ);
	System.out.println("ProductPrice : " +PP);
	ProductClass pc=new ProductClass();	
	}
}
