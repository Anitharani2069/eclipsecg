package prod;

class MyClass<X> {
X ob;
 MyClass(X o) {
	ob = o;
}
X getOb() {
	return ob;
}
class MySubClass<T,V> extends MyClass<T> {
	V ob2;
	MySubClass(T o, V o2) {
		super(o);
		ob2=o2;
	}
	V getOb2() {
		return ob2;
		
	}
}

	public static void main(String args[]) {
	MySubClass<String,Integer> Ob= new MySubClass<String,Integer>(27,"Xav");
	System.out.println(" ");
		
	}
}
