package prod;
import java.util.Scanner;
public class LargestNo {
	public void caluclateBig(int n[]) {
		int num=n.length;
		int arr[]=new int[num];
		int temp=0;
	        for(int i = 0; i < num; i++)
	        	for(int j=i+1;j<num;j++)
	        {
	            if(n[i]<n[j])
	            {
	               temp=n[i];
	               n[i]=n[j];
	               n[j]=temp;
	            }
	        }
	System.out.println(n[0]+" "+n[1]);

		}
		public static void main(String args[]) 
		{
			Scanner sc=new Scanner(System.in);
			int n=sc.nextInt();
			int arr[]=new int[n];
			for(int i=0;i<n;i++)
			{
				arr[i]=sc.nextInt();
			}
			LargestNo ln=new LargestNo();
			ln.caluclateBig(arr);
			
	}
}

		
