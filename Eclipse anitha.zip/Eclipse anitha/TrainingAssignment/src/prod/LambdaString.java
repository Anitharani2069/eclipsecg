package prod;
import java.util.function.*;
 class Sample {
	static void display(String s)
	{
		System.out.println(s);
	}
 }
	public class LambdaString {
public static void main(String args[]) {
	Sample obj=new Sample();
Consumer<String> c=Sample::display;
c.accept("Hello");
}
}
