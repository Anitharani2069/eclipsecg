package prod;

public interface supplier {

	public String get(String supplier);

}
