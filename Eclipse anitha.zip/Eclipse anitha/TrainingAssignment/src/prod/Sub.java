package prod;

public class Sub extends Base {

}
