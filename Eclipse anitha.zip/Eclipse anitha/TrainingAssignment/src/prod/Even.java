package prod;
import java.util.Scanner;
public class Even {
public void getEven(int n[]) {
	int number=n.length;  //array length initialize
	for(int i=0;i<number;i++) {
		if(i%2==0) {
			System.out.println(n[i]);
	}
		}
}
public static void main(String args[]) {
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter the array size");
	int digit=scan.nextInt();
	System.out.println("Enter the array of no");
	int arr[]=new int[digit];
	for(int i=0;i<digit;i++) {
		arr[i]=scan.nextInt();
	}
	Even even=new Even();
	even.getEven(arr);
}
}
