/*
 * create table user_info(id number(10), name varchar2(200));
 */
import java.sql.*;
public class PreparedStatementDemo {
	public static void main(String args[]){  
		try{  
		Class.forName("oracle.jdbc.driver.OracleDriver");  
		  
		Connection con=DriverManager.getConnection(""
				+"jdbc:oracle:thin:@localhost:1521:xe","system","password");  
		  
		PreparedStatement stmt=con.prepareStatement
				("insert into user_info values(?,?)");  
		stmt.setString(2,"Ratan");
		stmt.setInt(1,101);//1 specifies the first parameter in the query  
		stmt.executeUpdate();  
		System.out.println(" records inserted");  
		con.close();  
		  
		}catch(Exception e){ System.out.println(e);}  
		  
		}  
}
