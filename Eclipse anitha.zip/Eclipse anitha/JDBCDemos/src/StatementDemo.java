/*
 * create table user_info(id number(10), name varchar2(200));
 */
import java.sql.*;
public class StatementDemo {
	public static void main(String args[])throws Exception{  
		Class.forName("oracle.jdbc.driver.OracleDriver");  
		Connection con=DriverManager.getConnection(
		"jdbc:oracle:thin:@localhost:1521:xe","system","password");  
		Statement stmt=con.createStatement(); 
		stmt.execute("insert into user_info values(102,'Jack')");
		System.out.println("record inserted");
		con.close();  
		}
}
