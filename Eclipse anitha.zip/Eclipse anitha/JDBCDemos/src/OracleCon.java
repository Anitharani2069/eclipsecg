import java.sql.*;  
class OracleCon{  
public static void main(String args[]){  
try{  
//step1 load the driver class for oracle  
Class.forName("oracle.jdbc.driver.OracleDriver");  
  
//step2 create  the connection object  
Connection con=DriverManager.getConnection(  
"jdbc:oracle:thin:@localhost:1521:xe1","system","password");  
  
//step3 create the statement object  
Statement stmt=con.createStatement();  

//PreparedStatement pstm=con.prepareStatement("") ;
//CallableStatement cstm=con.prepareCall("");
con.close();   
}catch(Exception e){ System.out.println(e);}  
  
}  
}  



/*Access
 * Type 1 driver
 * Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
 * Connection con2=DriverManager.getConnection (�jdbc : odbc : oracle�,�system�,�password�); 
 */

/* Type 2 driver for oracle 
 * String ConnectMe=("jdbc:polite:system/password:polite; Data_Directory=<ORACLE_HOME>;Database=polite;IsolationLevel=SINGLE USER; Autocommit=ON;CursorType=DYNAMIC")
    Class.forName("oracle.lite.poljdbc.POLJDBCDriver")
   Connection conn = DriverManager.getConnection(ConnectMe)
 
 */
 
/* MYSQL
 * Type 4
 * Class.forName("com.mysql.jdbc.Driver"); 
con=DriverManager.getConnection("jdbc:mysql://localhost:3306/karthicraj","mysql","mysql"); 
 */

