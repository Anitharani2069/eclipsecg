/*
 * create table TestEmp(EmpID number(20), EmpName varchar2(50), JoinDate date);

CREATE SEQUENCE TestEmpId_sequence
START WITH 1;

SELECT * FROM TESTEMP
 */

import java.sql.*;
public class InsertDateDemo {
	public static void main(String args[]){
		try{ 
			java.util.Date d_Date=new java.util.Date();
			long l_Date=d_Date.getTime();
			java.sql.Date s_Date=new java.sql.Date(l_Date);
			System.out.println(s_Date);
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","password");  
			PreparedStatement stmt=con.prepareStatement("insert into TestEmp values(TestEmpId_sequence.nextval,?,?)");  
			stmt.setString(1,"Ratan");
			stmt.setDate(2, s_Date);
			  
			int i=stmt.executeUpdate();  
			System.out.println(i+" records inserted");  
			  
			con.close();  
			  
			}catch(Exception e){ System.out.println(e);}  
			  
	}

}
