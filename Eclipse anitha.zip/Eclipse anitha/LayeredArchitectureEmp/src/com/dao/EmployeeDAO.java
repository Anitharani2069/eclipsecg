package com.dao;
import java.util.*;
import com.bean.*;
public class EmployeeDAO {
	ArrayList alObj=new ArrayList();
	public void addEmployeeData(Employee obj) {
		
		alObj.add(obj);
		
	}
	
	public Employee getEmployeeDetails() {
		Employee obj=(Employee)alObj.get(0);
		return obj;
	}
	

}
