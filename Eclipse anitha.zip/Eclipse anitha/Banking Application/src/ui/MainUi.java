package ui;
import java.util.Scanner;
public class MainUi {
public static void main(String args[]) {
	int ch;
	char choice;
	BankAccountDetails badObj=new BankAccountDetails();
	Scanner sc=new Scanner(System.in);
		do
		{
			System.out.println("1.Create Account");
			System.out.println("2.Show Balance");
			System.out.println("3.Deposit");
			System.out.println("4.WithDraw");
			System.out.println("5.FundTransfer");
			System.out.println("6.PrintTransactions");
			System.out.println("7.Show Accounts");
			System.out.println("Enter your choice:");
			ch=sc.nextInt();
			switch(ch)
			{
			case 1:
				badObj.createAccount();
				break;
			case 2:
				badObj.showBalance();
				break;
			case 3:
				badObj.deposit();
				break;
			case 4:
				badObj.withDraw();
				break;
			case 5:
				badObj.fundTransfer();
				break;
			case 6:
				badObj.showAccounts();
				break;
			case 7:
				System.exit(0);
			default :
				System.out.println("Enter Valid Choice:");
				break;
			}
			System.out.println("Do you want to continue (y/n)...? ");
			choice =sc.next().charAt(0);
			if(choice=='y'||choice=='Y')
				continue;
			else {
				System.out.println("Thankyou!");
				System.exit(0);
			}
		}
		while(ch!=7);
		sc.close();	
	}
}
