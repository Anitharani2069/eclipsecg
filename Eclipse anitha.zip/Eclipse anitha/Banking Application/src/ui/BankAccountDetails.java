package ui;
import java.util.Scanner;

import bean.AccountType;
import bean.BankAccount;
public class BankAccountDetails {
	static Scanner sc=new Scanner(System.in);
public static void createAccount() {
	System.out.println("Enter account no");
	long accNo=sc.nextLong();
	System.out.println("Enter account holder name");
	String accHolderName=sc.next();
	System.out.println("Enter mobile no");
	long mobileNo=sc.nextLong();
	System.out.println("Enter account initial balance");
	double balance=sc.nextDouble();
	System.out.println("Enter the type of account");
	String accType=sc.next();
	BankAccount baObj=new BankAccount(accNo,accHolderName,mobileNo,balance,AccountType.valueOf(accType.toUpperCase()));
	System.out.println("Account created successfully!");
	System.out.println(baObj);
}
public static void showBalance() {
	
}
public static void deposit() {
	
}
public static void withDraw() {
	
}
public static void fundTransfer() {
	
}
public static void printTransactions() {
	
}
public static void showAccounts() {
	
}

}
