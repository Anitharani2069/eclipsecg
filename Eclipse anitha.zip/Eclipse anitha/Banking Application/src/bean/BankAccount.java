package bean;

public class BankAccount {
private long accontNo;
private String accHolderName;
private long mobileNo;
private double balance;
private AccountType accType;
public BankAccount() {
	
}
public BankAccount(long accontNo, String accHolderName, long mobileNo, double balance, AccountType accType) {
	super();
	this.accontNo = accontNo;
	this.accHolderName = accHolderName;
	this.mobileNo = mobileNo;
	this.balance = balance;
	this.accType = accType;
}
public long getAccontNo() {
	return accontNo;
}
public void setAccontNo(long accontNo) {
	this.accontNo = accontNo;
}
public String getAccHolderName() {
	return accHolderName;
}
public void setAccHolderName(String accHolderName) {
	this.accHolderName = accHolderName;
}
public long getMobileNo() {
	return mobileNo;
}
public void setMobileNo(long mobileNo) {
	this.mobileNo = mobileNo;
}
public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}
public AccountType getAccType() {
	return accType;
}
public void setAccType(AccountType accType) {
	this.accType = accType;
}
@Override
public String toString() {
	return "BankAccount [accontNo=" + accontNo + ", accHolderName=" + accHolderName + ", mobileNo=" + mobileNo
			+ ", balance=" + balance + ", accType=" + accType + "]";
}


		
}
