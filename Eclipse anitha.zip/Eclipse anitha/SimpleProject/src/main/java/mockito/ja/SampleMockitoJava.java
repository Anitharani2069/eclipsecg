package mockito.ja;

public class SampleMockitoJava {
	 public int sum(int a,int b) {
		int c=a+b;
		return c;
	}

}
	
