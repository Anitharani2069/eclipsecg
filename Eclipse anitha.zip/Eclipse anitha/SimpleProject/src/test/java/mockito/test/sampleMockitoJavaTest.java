package mockito.test;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;
import mockito.ja.SampleMockitoJava;

 class sampleMockitoJavaTest {
	@Test
	void test() {
		SampleMockitoJava smjObj=mock(SampleMockitoJava.class);
		when(smjObj.sum(3,2)).thenReturn(5);
		assertTrue(smjObj.sum(3,2)==5);
	}
 }
