package service;
import bean.EmployeeBean;
public class EmployeeService implements EmployeeServiceInterface{
	public void caluclateInsentive(EmployeeBean e) {
	double d=e.getSalary()+5000;
	e.setSalary(d);
}

}
