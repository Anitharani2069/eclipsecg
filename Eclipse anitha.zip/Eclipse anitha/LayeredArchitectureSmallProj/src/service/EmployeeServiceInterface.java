
package service;
import bean.EmployeeBean;
public interface EmployeeServiceInterface {
	public void caluclateInsentive(EmployeeBean e); 
}
