package ui;
import java.util.Scanner;
import bean.EmployeeBean;
import dao.EmployeeDao;
import service.EmployeeService;
import salary.SalaryException;
public class EmployeeUi {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee Id:");
		int Id=sc.nextInt();
		System.out.println("Enter Employee Name:");
		String Name=sc.next();
		System.out.println("Enter Employee Salary:");
		double Salary=sc.nextDouble();
		EmployeeBean e=new EmployeeBean(Id,Name,Salary);
		EmployeeService es=new EmployeeService();
		EmployeeDao ed=new EmployeeDao();
		es.caluclateInsentive(e);
		ed.storeEmployeeDetails(e);
		ed.retrieveEmployeeDetails(e);
		try
		{
			if(Salary<5000)
			{
				throw new SalaryException("Salary should be greater than 5000");
			}
			else
			{
				System.out.println("Salary:"+Salary);
			}
		}
		catch(SalaryException e1) {
			e1.printStackTrace();
		}
	}
}
