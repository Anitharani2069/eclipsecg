package salary;

public class SalaryException extends Exception{
	public SalaryException(String args)
	{
		System.out.println(args);
	}

}
