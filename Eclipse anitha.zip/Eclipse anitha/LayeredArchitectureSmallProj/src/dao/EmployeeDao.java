package dao;
import java.util.Scanner;
import bean.EmployeeBean;
import ui.EmployeeUi;
public class EmployeeDao implements EmployeeDaoInterface {
	public void storeEmployeeDetails(EmployeeBean ei) {
			EmployeeBean e[]=new EmployeeBean[2];
			e[0]=ei;
	}
	public EmployeeBean retrieveEmployeeDetails(EmployeeBean e1) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee id");
		int eId =sc.nextInt();
		int id=e1.getEmpId();
		for (int i=0;i<=1;i++) {
			if(id==e1.getEmpId()) {
				System.out.println(e1);
			}
		}
		
		return e1;
	}
}
