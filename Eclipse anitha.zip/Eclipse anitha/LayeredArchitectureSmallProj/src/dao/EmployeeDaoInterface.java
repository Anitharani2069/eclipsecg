package dao;
import bean.EmployeeBean;
public interface EmployeeDaoInterface {
	public void storeEmployeeDetails(EmployeeBean e1);
	public EmployeeBean retrieveEmployeeDetails(EmployeeBean e1);
}
