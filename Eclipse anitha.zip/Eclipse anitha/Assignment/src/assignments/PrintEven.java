package assignments;
import java.util.Scanner;
public class PrintEven {
	public void getEven(int n[]) {
		int len=n.length;
		for(int i=0;i<len;i++)
		{
			if (i%2==0)
			{
			System.out.println(n[i]);
			}
		}
}
	public static void main(String args[]) {
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter the array size");
			int n=sc.nextInt();
			int arr[]=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		PrintEven pe=new PrintEven();
		pe.getEven(arr);
	}
}
