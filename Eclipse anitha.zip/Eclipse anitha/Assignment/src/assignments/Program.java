package assignments;

public class Program{
	static void getProgram() {
	}
	Program p=new Program();
	int no;
	String name;
	long salary;
public Program() {

}
public Program(int no, String name, long salary) {
	super();
	this.no = no;
	this.name = name;
	this.salary = salary;
}
public int getNo() {
	return no;
}
public void setNo(int no) {
	this.no = no;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public long getSalary() {
	return salary;
}
public void setSalary(long salary) {
	this.salary = salary;
}
@Override
public String toString() {
	return "Program [no=" + no + ", name=" + name + ", salary=" + salary + "]";
}
}
