package assignments;

abstract class Program1 {

}
