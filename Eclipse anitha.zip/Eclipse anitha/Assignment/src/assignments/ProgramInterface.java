package assignments;

public interface ProgramInterface {


}
